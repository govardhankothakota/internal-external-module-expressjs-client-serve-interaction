const os = require("node:os");
const path = require("node:path");
const moment = require("moment");
const express = require("express");
const cors = require("cors")
let {xiaomiMobileName,xiaomiMobilePrice,xiaomiHighlights,
  xiaomiOsProcessorFeatures,xiaomiNetworkType, xiaomiDescription,
} = require("./Xiaomi ");

let app = express();
app.use(cors());

app.get("/IMDb",(req,res)=>{ 
    let movies = [  
  {
    no: 1,
    movie: "Student No: 1",
    year:"2001",
    rating: "6.6",
    stars:"N.T. Rama Rao Jr., Gajala, Rajeev Kanakala",
    image: "https://m.media-amazon.com/images/M/MV5BZmJiNzZjOWItOTUwNS00NTFmLTk1OWYtZmUzZWMwZDg2MGQ4XkEyXkFqcGdeQXVyNTM2NTg3Nzg@._V1_.jpg",
    imdbURL: "https://www.imdb.com/title/tt1283956/?ref_=ls_t_1"
  },
  {
    no: 2,
    movie: "Simhadri",
    year:"2003",
    rating: "7.3",
    stars:"N.T. Rama Rao Jr, Bhoomika Chawla, Ankita",
    image: "https://preview.redd.it/simhadri-appreciation-post-v0-0codeh0yzy0b1.jpg?auto=webp&s=c909bc883cfd560c4b2769e0392e2e3ef83e479b",
    imdbURL: "https://www.imdb.com/title/tt0375066/?ref_=ls_t_2"
  },
  {
    no: 3,
    movie: "Sye Challenge",
    year:"2005",
    rating: "7.6",
    stars:"Prabhas, Bhanupriya, Shriya Saran",
    image: "https://images.justwatch.com/poster/308632736/s718/sye.jpg",
    imdbURL: "https://www.imdb.com/title/tt0467003/?ref_=ls_t_3"
  },
  {
    no: 4,
    movie: "Chatrapathi",
    year:"2004",
    rating: "7.4",
    stars:"Nithiin, Genelia Deshmukh, Preeti Nigam",
    image: "https://m.media-amazon.com/images/M/MV5BNjUzOWJkY2YtMTU5ZC00NTVmLTlmNzUtYzQ3YzRhNTczZDVkXkEyXkFqcGdeQXVyMTQyMzAwMjUz._V1_.jpg",
    imdbURL: "https://www.imdb.com/title/tt0843328/?ref_=ls_t_4"
  },
  {
    no: 5,
    movie: "Vikramarkudu",
    year:"2006",
    rating: "7.7",
    stars:"Ravi Teja, Anushka Shetty, Annie",
    image: "https://m.media-amazon.com/images/M/MV5BNDQ4MDFjNmQtNGU0MC00ZDVmLTliNmItZWE1NjRkNjYxMmFlXkEyXkFqcGdeQXVyMTQyMzAwMjUz._V1_.jpg",
    imdbURL: "https://www.imdb.com/title/tt0858492/?ref_=ls_t_5"
  },
  {
    no: 6,
    movie: "Yamadonga",
    year:"2007",
    rating: "7.2",
    stars:"N.T. Rama Rao Jr., Mohan Babu, Priyamani",
    image: "https://static.toiimg.com/photo/61315915.cms",
    imdbURL: "https://www.imdb.com/title/tt0924317/?ref_=ls_t_6"
  },
  {
    no: 7,
    movie: "Magadheera",
    year:"2009",
    rating: "7.7",
    stars:"Ram Charan, Kajal Aggarwal, Dev Gill",
    image: "https://m.media-amazon.com/images/M/MV5BNDRkNmNiYTYtYjIxNi00MjQyLThlZWQtYmU0NDMxNDE0NWYzXkEyXkFqcGdeQXVyODMyODMxNDY@._V1_FMjpg_UX1000_.jpg",
    imdbURL: "https://www.imdb.com/title/tt1447500/?ref_=ls_t_7"
  },
  {
    no: 8,
    movie: "Maryada Ramanna",
    year:"2010",
    rating: "7.4",
    stars:"Sunil, SaloniAswani, Nagineedu",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTcKG0TJjl4TdnD5MIp4bRuJSte_BexxgXzHg&s",
    imdbURL: "https://www.imdb.com/title/tt1582546/?ref_=ls_t_8"
  },
  {
    no: 9,
    movie: "Eega",
    year:"2012",
    rating: "7.7",
    stars:"Sudeep, Nani, Samantha Ruth Prabhu",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTPXW8wkMGdOSHlovRZZc0YIjfPNheG7kHtEw&s",
    imdbURL: "https://www.imdb.com/title/tt2258337/?ref_=ls_t_9"
  },
  {
    no: 10,
    movie: "Baahubali: The Beginning",
    year:"2015",
    rating: "7.2",
    stars:"Prabhas, Rana Daggubati, Anushka Shetty",
    image: "https://m.media-amazon.com/images/M/MV5BYWVlMjVhZWYtNWViNC00ODFkLTk1MmItYjU1MDY5ZDdhMTU3XkEyXkFqcGdeQXVyODIwMDI1NjM@._V1_.jpg",
    imdbURL: "https://www.imdb.com/title/tt2631186/?ref_=ls_t_10"
  },
  {
    no: 11,
    movie: " Baahubali 2: The Conclusion",
    year:"2017",
    rating: "8.2",
    stars:"Prabhas, Rana Daggubati, Anushka Shetty",
    image: "https://m.media-amazon.com/images/I/71i8a-PnChL._AC_UF1000,1000_QL80_.jpg",
    imdbURL: "https://www.imdb.com/title/tt4849438/?ref_=ls_t_11"
  },
  {
    no: 12,
    movie: " RRR",
    year:"2022",
    rating: "7.8",
    stars:"N.T. Rama Rao Jr., Ram Charan, Ajay Devgn",
    image: "https://m.media-amazon.com/images/M/MV5BODUwNDNjYzctODUxNy00ZTA2LWIyYTEtMDc5Y2E5ZjBmNTMzXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_.jpg",
    imdbURL: "https://www.imdb.com/title/tt8178634/?ref_=ls_t_12"
  },
    ]
    res.json(movies)  
})

app.listen(7799, () => {
  console.log("Listening to port 7799");
});
app.get("/topmobiles",(req,res)=>{
  let mobiles = [
    {
      mobileNo : "1",
      mobileImage : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyrphGt4CpksdsfbTaFdj04RSh9Zr-WnXk8g&s",
      mobileName : "Apple iPhone 15 Pro Max",
      mobilePrice : "1,48,900/-",
      mobileStorage : "256 GB ROM",
      mobileDisplay : "17.02 cm (6.7 inch) Super Retina XDR Display",
      mobileCamera : "48MP + 12MP + 12MP | 12MP Front Camera",
      mobileProcessor : "A17 Pro Chip, 6 Core Processor",
      mobileBattery : "4441 mAh Battery"

    },
    {
      mobileNo : "2",
      mobileImage : "https://m.media-amazon.com/images/I/81vxWpPpgNL._AC_UF1000,1000_QL80_.jpg",
      mobileName : "Samsung Galaxy S24 Ultra",
      mobilePrice : "1,29,000/-",
      mobileStorage : "12 GB RAM | 256 GB ROM",
      mobileDisplay : "17.27 cm (6.8 inch) Quad HD+ Display",
      mobileCamera : "200MP + 50MP + 12MP + 10MP | 12MP Front Camera",
      mobileProcessor : "Snapdragon 8 Gen 3 Processor",
      mobileBattery : "5000 mAh Battery"

    },
    {
      mobileNo : "3",
      mobileImage : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2Ogpik7Hq831kCCp2tCFBKLSvuu5dC88OIg&s",
      mobileName : "Xiaomi 14 Ultra",
      mobilePrice : "99,900/-",
      mobileStorage : "16 GB RAM | 512 GB ROM",
      mobileDisplay :  "17.09 cm (6.73 inch) Display",
      mobileCamera : "50MP + 50MP + 50MP + 50MP | 32MP Front Camera",
      mobileProcessor : "Snapdragon 8 Gen 3 Mobile Platform Processor",
      mobileBattery : "5000 mAh Battery"
    },
    {
      mobileNo : "4",
      mobileImage : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRX1ahBeaChGZRWtIH1RqvY3wxk-fh7ZS8f_w&s",
      mobileName : "OnePlus 12 ",
      mobilePrice : "64,999/-",
      mobileStorage : "16 GB RAM | 512 GB ROM",
      mobileDisplay :  "17.09 cm (6.73 inch) Display",
      mobileCamera : "50MP Rear Camera",
      mobileProcessor : "Qualcomm SM8650-AB Snapdragon 8 Gen 3 (4 nm) Processor",
      mobileBattery : "5400 mAh Battery"
    },
    {
      mobileNo : "5",
      mobileImage : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBvySHmkl6iY4Vw20o5CVzXvvbCCnXJMCNpw&s",
      mobileName : "Vivo X100 Pro",
      mobilePrice : "89,999/-",
      mobileStorage : "16 GB RAM | 512 GB ROM",
      mobileDisplay :  "17.22 cm (6.78 inch) Full HD+ Display",
      mobileCamera : "50MP + 50MP + 50MP | 32MP Front Camera",
      mobileProcessor : "Dimensity 9300 Processo",
      mobileBattery : "5400 mAh Battery"
    },
    {
      mobileNo : "6",
      mobileImage : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUjQSyYUUc0JdxQ83uvb9Bv-xrESZckz6b_w&s",
      mobileName : "Vivo X Fold 3 Pro",
      mobilePrice : "1,59,999/-",
      mobileStorage : "16 GB RAM | 512 GB ROM",
      mobileDisplay :  "16.59 cm (6.53 inch) Display",
      mobileCamera : "50MP + 50MP + 64MP | 32MP Front Camera",
      mobileProcessor : "8 Gen 3 Mobile Platform Processor",
      mobileBattery : "5700 mAh Battery"
    },
    {
      mobileNo : "7",
      mobileImage : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9xpk4q5JqD9uwNdlFoPBhuvrQbRBDaEt7hA&s",
      mobileName : "OPPO Find N3 Flip",
      mobilePrice : "74,999/-",
      mobileStorage : "12 GB RAM | 512 GB ROM",
      mobileDisplay :  "17.27 cm (6.8 inch) Full HD Display",
      mobileCamera : "50MP + 48MP + 32MP | 32MP Front Camera",
      mobileProcessor : "Mediatek Dimensity 9200 Processor",
      mobileBattery : "4300 mAh Battery"
    },
    {
      mobileNo : "8",
      mobileImage : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGjBRRCZWXe1XDUBeCJsdyL2HVz27Pnngiow&s",
      mobileName : "Google Pixel 8 Pro",
      mobilePrice : "98,999/-",
      mobileStorage : "12 GB RAM | 512 GB ROM",
      mobileDisplay :  "17.02 cm (6.7 inch) Full HD+ AMOLED Display",
      mobileCamera : "50MP + 48MP + 48MP | 10.5MP Front Camera",
      mobileProcessor : "Tensor G3 Processor",
      mobileBattery : "5050 mAh Battery"
    },
    {
      mobileNo : "9",
      mobileImage : "https://m.media-amazon.com/images/I/71U+YdsvMPL._AC_UF1000,1000_QL80_.jpg",
      mobileName : "Samsung Galaxy Z Flip 5",
      mobilePrice : "99,999/-",
      mobileStorage : "8 GB RAM | 256 GB ROM",
      mobileDisplay : "17.02 cm (6.7 inch) Display",
      mobileCamera : "12MP + 12MP | 10MP Front Camera",
      mobileProcessor : "Snapdragon 8 Gen 2 Processor",
      mobileBattery : "3700 mAh Battery"
    },
    {
      mobileNo : "10",
      mobileImage : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSgDPpUht4rcQHyZRv4It9jMUzDtDRnVRCElQ&s",
      mobileName : "OnePlus Open",
      mobilePrice : "1,26,290/-",
      mobileStorage : "16 GB RAM | 512 GB ROM",
      mobileDisplay : "19.86 cm (7.82 inch) Display",
      mobileCamera : "64MP Rear Camera",
      mobileProcessor : "Snapdragon Android 13.0,Octa core",
      mobileBattery : "4805 mAh Battery"
    },
    {
      mobileNo : "11",
      mobileImage : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-WEG-GWF5IayStMvbbR959rChN2_w44hA6Q&s",
      mobileName : "ASUS ROG Phone 8 Pro Ultimate Edition",
      mobilePrice : "1,26,290/-",
      mobileStorage : "18 GB RAM | 512 GB ROM",
      mobileDisplay : "17.22 cm (6.78 inch) Full HD+ Display",
      mobileCamera : "64MP + 13MP + 5MP | 24MP Front Camera",
      mobileProcessor : "Qualcomm Snapdragon 888 Plus (SM8350) Processor",
      mobileBattery : "6000 mAh Battery"
    },
    {
      mobileNo : "12",
      mobileImage : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRc1q03k3IeU2vIsuvbujWddw9qPGkVeDOaSw&s",
      mobileName : "Motorola Edge 50 Ultra",
      mobilePrice : "54,999/-",
      mobileStorage : "12 GB RAM | 512 GB ROM",
      mobileDisplay : "17.02 cm (6.7 inch) Display",
      mobileCamera : "50MP + 50MP + 64MP | 50MP Front Camera",
      mobileProcessor : "8s Gen 3 Mobile Platform Processor",
      mobileBattery : "4500 mAh Battery"
    },

  ]
 res.json(mobiles)

})
app.listen(2961,()=>{
  console.log("Listening to port 2961")
})



console.log(xiaomiMobileName);
console.log(xiaomiMobilePrice);
console.log(xiaomiHighlights);
console.log(xiaomiOsProcessorFeatures);
console.log(xiaomiNetworkType);
xiaomiDescription();

console.log(os.platform());
console.log(os.totalmem() / 1024 / 1024 / 1024);
console.log(os.freemem() / 1024 / 1024 / 1024);
console.log(os.type());
console.log(os.version());
console.log(os.release());
console.log(path.parse("https://www.w3schools.com/js/default.asp"));

console.log(moment().format("MMMM Do YYYY, h:mm:ss a"));
console.log(moment().add(120, "days").calendar());
